import Home from './Home'
import React from 'react'

function Mediator() {
  return (
   
      <Home/>
  
  )
}

export default Mediator
